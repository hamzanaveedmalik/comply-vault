ComplyVault — Sample Audit Pack
================================
This is a redacted illustrative sample showing the exact output
ComplyVault produces from a single client meeting recording.

Files included:
01 — Compliance Note (PDF): Structured documentation with flags,
     action items, recommendations, and advisor sign-off page.
02 — Evidence Map (CSV): Every compliance claim linked to a
     timestamped transcript snippet with confidence score.
03 — Version History (CSV): Full audit trail of every edit made
     before finalization.
04 — Transcript (TXT): Speaker-labeled, timestamped full transcript.

All figures and names are fictional placeholders.
complyvault.co | hamza@complyvault.co